package com.amir.elemental.boss;

import java.util.List;

/**
 * Version-independent boss design data. This is NOT entity registration.
 * Boss AI, spawn rules, loot and rendering must be implemented and tested later.
 */
public final class BossDefinitions {
    private BossDefinitions() {}

    public record Boss(String id, String displayName, String dimension,
                       int maxHealth, int attackDamage, String coreItem,
                       String signatureAbility) {}

    public static final List<Boss> ALL = List.of(
        new Boss("storm_golem", "Storm Golem", "minecraft:overworld", 250, 12,
                 "elemental_arsenal:storm_core", "chain_lightning"),
        new Boss("magma_titan", "Magma Titan", "minecraft:the_nether", 350, 16,
                 "elemental_arsenal:magma_heart", "lava_wave"),
        new Boss("frost_guardian", "Frost Guardian", "minecraft:overworld", 300, 14,
                 "elemental_arsenal:frozen_soul", "frost_nova"),
        new Boss("void_king", "Void King", "minecraft:the_end", 500, 20,
                 "elemental_arsenal:void_essence", "short_teleport")
    );
}
