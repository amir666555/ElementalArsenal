package com.amir.elemental;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import java.util.LinkedHashMap;
import java.util.Map;

/** First real item registration pass. API signatures must be validated with 26.2 mappings. */
public final class ModItems {
    public static final Map<String, Item> ITEMS = new LinkedHashMap<>();
    private static Item add(String id, int durability) {
        ResourceLocation location = ResourceLocation.fromNamespaceAndPath(ElementalArsenal.MOD_ID, id);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, location);
        Item.Properties props = new Item.Properties().setId(key);
        if (durability > 0) props.durability(durability);
        Item item = Registry.register(BuiltInRegistries.ITEM, key, new Item(props));
        ITEMS.put(id, item);
        return item;
    }
    public static void register() {
        String[] sets = {"thunder", "inferno", "frost", "void"};
        String[] gear = {"sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate", "leggings", "boots"};
        int[] durability = {4000, 6000, 8000, 10000};
        for (int i = 0; i < sets.length; i++) {
            for (String type : gear) add(sets[i] + "_" + type, durability[i]);
            add(sets[i] + "_core", 0);
            add(sets[i] + "_raw", 0);
            add(sets[i] + "_ingot", 0);
        }
        ElementalArsenal.LOGGER.info("Registered {} placeholder items", ITEMS.size());
    }
    private ModItems() {}
}
