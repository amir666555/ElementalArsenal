package com.amir.elemental;

/** Pure durability and boss-core repair rules, independent of Minecraft mappings.
 * Integration with damage events, item components and anvil UI is still required.
 */
public final class RepairRules {
    public enum Element {
        THUNDER(4000, "thunder_core"), INFERNO(6000, "inferno_core"),
        FROST(8000, "frost_core"), VOID(10000, "void_core");
        public final int maxDurability;
        public final String repairCore;
        Element(int maxDurability, String repairCore) {
            this.maxDurability = maxDurability;
            this.repairCore = repairCore;
        }
    }
    /** At 1 durability, gear becomes unusable but remains in inventory. */
    public static boolean isDisabled(int remainingDurability) {
        return remainingDurability <= 1;
    }
    /** Each matching boss core repairs 25% of maximum durability. */
    public static int repair(Element element, int remainingDurability, int cores) {
        if (cores < 0) throw new IllegalArgumentException("cores cannot be negative");
        long repaired = (long) Math.max(1, remainingDurability)
                + (long) cores * (element.maxDurability / 4);
        return (int) Math.min(element.maxDurability, repaired);
    }
    /** Only the core of the matching boss is valid for repair. */
    public static boolean canRepair(Element element, String itemId) {
        return element.repairCore.equals(itemId);
    }
    private RepairRules() {}
}
