# Build notes

Requirements: matching JDK, Gradle, Fabric Loom, Fabric Loader and Fabric API for the target Minecraft release. Versions in gradle.properties are unverified placeholders.

When dependencies and code are corrected, run `gradle build` in this project folder. A successful build should put the JAR in `build/libs/`. Do not rename the ZIP to JAR.

A build may currently fail because implementation and API compatibility are incomplete. No runnable JAR is included.
