# V5: Item registration pass

Added Java source registering 48 placeholder item IDs (36 equipment IDs, 4 cores, 4 raw materials, 4 ingots) with set-specific durability values. The equipment currently uses **generic Item classes**, not functional swords, tools, or equippable armor. The 4 ore blocks, world generation, bosses, biomes, recipes, loot tables and broken-at-1 behavior are NOT integrated. Existing worldgen JSON files are plans only.

This has NOT been compiled or tested for Minecraft 26.2. Fabric/Mojang mapping and version differences may require code changes. Do not put this ZIP in mods. This archive includes all previous files.
