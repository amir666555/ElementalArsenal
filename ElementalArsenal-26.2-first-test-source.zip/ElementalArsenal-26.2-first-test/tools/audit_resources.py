from pathlib import Path
import json, sys
root = Path(__file__).resolve().parents[1]
files = list((root / 'src/main/resources').rglob('*.json'))
errors = []
for p in files:
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'{p.relative_to(root)}: {exc}')
print(f'Checked {len(files)} JSON resources: {len(errors)} syntax errors')
for err in errors: print(err)
print('Note: valid JSON does NOT establish valid Minecraft registries or world generation.')
sys.exit(bool(errors))
