# Stage 8 — custom biome designs

Added four **design-only** biome specifications under `design/biomes/`:
- Thunder Mountains (Overworld)
- Inferno Wasteland (Nether)
- Frozen Crystal Forest (Overworld)
- Void Highlands (End)

These are NOT registered Minecraft biomes and will NOT generate in-game. They are design specifications, not datapack worldgen definitions. Existing ore-placement plans also do not yet generate ore. Actual Java biome registration, placement, features, boss entities, armor/tool behaviors, compilation, and gameplay testing are outstanding.

**Do not put this ZIP in `mods`.** Fabric and Minecraft 26.2 build dependency versions are unverified. The earlier ten-stage estimate was a planning estimate, not a promise of a playable JAR after stage ten.
