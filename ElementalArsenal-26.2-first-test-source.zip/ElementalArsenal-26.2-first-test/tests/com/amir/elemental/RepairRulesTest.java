package com.amir.elemental;
public class RepairRulesTest {
    public static void main(String[] args) {
        for (RepairRules.Element e : RepairRules.Element.values()) {
            check(RepairRules.repair(e, 1, 0) == 1, "zero cores");
            check(RepairRules.repair(e, 1, 1) == 1 + e.maxDurability/4, "one core");
            check(RepairRules.repair(e, 1, 4) == e.maxDurability, "cap");
            check(RepairRules.isDisabled(1), "disabled at 1");
            check(!RepairRules.isDisabled(2), "enabled at 2");
            check(RepairRules.canRepair(e, e.repairCore), "matching core");
            check(!RepairRules.canRepair(e, "other_core"), "mismatched core");
        }
        System.out.println("PASS: 28 repair-rule assertions");
    }
    private static void check(boolean ok, String name) { if (!ok) throw new AssertionError(name); }
}
