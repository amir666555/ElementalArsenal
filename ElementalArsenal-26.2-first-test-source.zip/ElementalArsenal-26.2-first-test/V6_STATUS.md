# V6 — Durability and boss-core repair rules

Added `RepairRules.java` with independent Java logic for:
- 4000 / 6000 / 8000 / 10000 durability per elemental set
- Disabled state at 1 durability (Elytra-style design)
- 25% durability restored per matching boss core
- Core matching validation

**Not yet implemented:** hooking rules into actual Minecraft damage/attack/mining events, anvil or repair GUI, boss drops, custom item classes, biome generation, or actual bosses. Existing item registrations are placeholders and may not compile with Minecraft 26.2 mappings. No runnable JAR was built or tested.
