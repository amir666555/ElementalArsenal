from pathlib import Path
import json,sys
root=Path(__file__).resolve().parent
files=list((root/'src/main/resources').rglob('*.json'))
errors=[]
for p in files:
    try:json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:errors.append(f"{p.relative_to(root)}: {e}")
java=list((root/'src/main/java').rglob('*.java'))
print(f"JSON files checked: {len(files)}; Java files present: {len(java)}")
print('JSON syntax:', 'PASS' if not errors else 'FAIL')
for error in errors:print(error)
print('NOTE: This does NOT compile or test the Minecraft mod.')
sys.exit(bool(errors))
