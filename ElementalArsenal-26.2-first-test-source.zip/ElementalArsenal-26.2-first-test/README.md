# Elemental Arsenal — stage 3: crafting and loot data (Minecraft 26.2 / Fabric)

**SOURCE PROJECT ONLY — NOT A WORKING JAR.** Keep the ZIP in Downloads; do not put it in `mods`.

This stage adds 36 JSON crafting recipes (9 equipment items per element), 4 ore loot tables, and block mining tags. It also retains the textures/models from stage 2.

Recipe design: O = corresponding elemental ore block; C = corresponding boss core. Every equipment recipe requires a boss core. These recipes are *data files*, not usable until the corresponding items and blocks are registered in Java.

Mining tags document the planned progression: Netherite -> Thunder -> Inferno -> Frost/Void. The `requires_inferno_pickaxe` custom tag **does not enforce the rule by itself**. Code for mining restrictions, ore generation, armor durability, broken-item behavior, boss entities and biomes is not yet implemented.

The original `gradle.properties` version placeholders remain **unverified**. No compilation or in-game test has been completed. Fabric/Minecraft 26.2 APIs must be checked before building.


## Stage 4 — ore world generation definitions
Added 8 worldgen JSON definitions (4 configured features and 4 placed features), plus four biome placement plans. These files describe where ore *should* generate once the ore blocks are registered and Fabric biome modifications are implemented.

**NOT IMPLEMENTED:** Java registration for blocks, configured/placed features and biome modifications; generation in existing chunks; custom biomes; bosses; playable JAR. These JSONs alone do not make ore generate. Values and JSON compatibility for 26.2 are unverified.
