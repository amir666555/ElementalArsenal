# V7: Boss design definitions

Added: Java boss definition records and JSON balancing/design plan for Storm Golem, Magma Titan, Frost Guardian, and Void King.

NOT implemented: actual boss entities, AI, abilities, natural spawning, loot tables, models, animations, biome generation, or tested Minecraft 26.2 integration. Bosses cannot yet be summoned or fought.

This ZIP contains all earlier prototype files. It is source/planning material, NOT a runnable mod JAR. Fabric dependency versions are not verified, and compilation was not performed.
